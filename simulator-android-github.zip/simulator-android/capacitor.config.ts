import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.kiska.pcsimulator',
  appName: 'PC Simulator',
  webDir: 'www'
};

export default config;
