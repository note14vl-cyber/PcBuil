# 🖥️ Computer Servicing App - 3D PC Building Simulator

An interactive educational application built with **Ionic Angular** and **Three.js** for learning computer system servicing through immersive 3D simulation.

![Ionic](https://img.shields.io/badge/Ionic-8.0.0-blue)
![Angular](https://img.shields.io/badge/Angular-20.0.0-red)
![Three.js](https://img.shields.io/badge/Three.js-0.181.2-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5.9.0-blue)

## 🌟 Features

### 📚 Three Learning Levels

#### **Level 1: Video Tutorials**

- Comprehensive video guides on PC components
- Learn about motherboards, CPUs, GPUs, RAM, storage, and more
- Interactive video player with progress tracking

#### **Level 2: Knowledge Quiz**

- Test your understanding with interactive quizzes
- Multiple-choice questions on PC components
- Instant feedback and scoring system
- Progress tracking

#### **Level 3: 3D PC Building Simulator** ⭐

The crown jewel of the app - a fully interactive 3D PC assembly simulator!

**Features:**

- 🎮 **Realistic 3D Models** - Photorealistic PC components with PBR materials
- 🧲 **Smart Magnetic Snapping** - Progressive snap strength for easy assembly
- 👻 **Dual-Layer Ghost Indicators** - Wireframe + glowing solid guides
- 💬 **Real-Time Hints** - Dynamic feedback during component placement
- 📦 **Boundary Constraints** - Components automatically stay inside the case
- ✨ **Enhanced Visual Feedback** - Semi-transparent drag, pulsing animations
- 🎯 **Distance Tracking** - See how close you are to the target position
- 🔄 **Automatic Rotation Alignment** - Components orient correctly when snapping
- 🎨 **Modern UI** - Glassmorphism effects and smooth animations
- 📊 **Progress Tracking** - Track your assembly completion

**Components Included:**

- ATX Mid-Tower Case
- ATX Motherboard with VRM heatsinks
- Intel i7 CPU with IHS
- AIO CPU Cooler with RGB
- DDR5 RAM modules
- NVIDIA RTX GPU
- 750W Power Supply
- M.2 NVMe SSD

### 🎨 Design Highlights

- **Modern Glassmorphism UI** - Beautiful translucent cards with backdrop blur
- **Neon Green Theme** (#00ff88) - Eye-catching and modern
- **Smooth Animations** - Professional transitions and effects
- **Responsive Design** - Works on desktop and mobile
- **Dark Mode** - Easy on the eyes for extended learning sessions

## 🚀 Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn
- Ionic CLI

### Installation

1. **Clone the repository**

   ```bash
   git clone https://github.com/Tw1stz10/simulator.git
   cd simulator
   ```

2. **Install dependencies**

   ```bash
   npm install
   ```

3. **Run the development server**

   ```bash
   npm start
   # or
   ionic serve
   ```

4. **Open your browser**
   ```
   http://localhost:4200
   ```

### Build for Production

```bash
npm run build
```

The build artifacts will be stored in the `www/` directory.

## 📱 Project Structure

```
computer-servicing-app/
├── src/
│   ├── app/
│   │   ├── pages/
│   │   │   ├── home/              # Landing page
│   │   │   ├── level1-videos/     # Video tutorials
│   │   │   ├── level2-quiz/       # Interactive quiz
│   │   │   ├── level3-simulator/  # 3D PC building simulator
│   │   │   └── profile/           # User profile
│   │   ├── services/
│   │   │   ├── progress.ts        # Progress tracking
│   │   │   ├── storage.ts         # Local storage
│   │   │   └── data.service.ts    # Data management
│   │   └── models/
│   │       └── interfaces.ts      # TypeScript interfaces
│   ├── assets/                    # Images and icons
│   ├── theme/                     # Global styles
│   └── environments/              # Environment configs
├── SIMULATOR_ENHANCEMENTS.md      # Detailed enhancement docs
└── package.json
```

## 🎮 How to Use the 3D Simulator

1. **Navigate to Level 3** from the home page
2. **Pick up a component** by clicking and dragging
3. **Watch for visual cues**:
   - Ghost indicator shows target position
   - Boundary box appears (green outline)
   - Hint displays at the top
4. **Drag the component** inside the case
   - It will automatically stay within boundaries
   - Magnetic pull activates when close to target
5. **Release when you see** "✓ Release to install!"
6. **Repeat** for all components
7. **Complete the build** and power on your PC!

## 🔧 Technologies Used

### Frontend Framework

- **Ionic 8.0** - Cross-platform UI framework
- **Angular 20.0** - Modern web framework
- **TypeScript 5.9** - Type-safe JavaScript

### 3D Graphics

- **Three.js 0.181** - WebGL 3D library
- **OrbitControls** - Camera controls
- **PBR Materials** - Physically-based rendering

### Styling

- **SCSS** - Advanced CSS preprocessing
- **Ionic Components** - Pre-built UI components
- **Custom Animations** - Smooth transitions

### Storage

- **Ionic Storage** - Local data persistence
- **RxJS** - Reactive programming

## 📊 Recent Enhancements

### Version 2.0 - Major Simulator Improvements

✅ **Smart Boundary System** - Components stay inside the case  
✅ **Enhanced Magnetic Snapping** - Progressive pull strength  
✅ **Dual-Layer Ghost Indicators** - Better visibility  
✅ **Real-Time Hint System** - Dynamic feedback  
✅ **Enhanced Visual Feedback** - Semi-transparent drag  
✅ **Smooth Animations** - Pulsing effects  
✅ **Larger Components** - 1.5x scale for better visibility  
✅ **Fixed Positioning** - Proper component alignment

See [SIMULATOR_ENHANCEMENTS.md](./SIMULATOR_ENHANCEMENTS.md) for detailed documentation.

## 🎓 Educational Value

This app is designed for:

- **Computer Science Students** - Learn PC assembly visually
- **IT Trainees** - Practice before handling real hardware
- **Tech Enthusiasts** - Understand PC components better
- **Educators** - Teaching tool for computer hardware courses

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

This project is open source and available under the [MIT License](LICENSE).

## 👨‍💻 Author

**Tw1stz10**

- GitHub: [@Tw1stz10](https://github.com/Tw1stz10)

## 🙏 Acknowledgments

- Ionic Framework team for the amazing UI toolkit
- Three.js community for the powerful 3D library
- All contributors and testers

## 📧 Support

If you have any questions or need help, please open an issue on GitHub.

---

**⭐ If you find this project useful, please give it a star!**

Built with ❤️ using Ionic, Angular, and Three.js
