import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full',
  },
  {
    path: 'home',
    loadComponent: () => import('./pages/home/home.page').then(m => m.HomePage)
  },
  {
    path: 'profile',
    loadComponent: () => import('./pages/profile/profile.page').then(m => m.ProfilePage)
  },
  {
    path: 'level1-videos',
    loadComponent: () => import('./pages/level1-videos/level1-videos.page').then(m => m.Level1VideosPage)
  },
  {
    path: 'level2-quiz',
    loadComponent: () => import('./pages/level2-quiz/level2-quiz.page').then(m => m.Level2QuizPage)
  },
  {
    path: 'level3-simulator',
    loadComponent: () => import('./pages/level3-simulator/level3-simulator.page').then(m => m.Level3SimulatorPage)
  },
];
