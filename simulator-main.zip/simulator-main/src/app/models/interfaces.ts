export interface VideoLesson {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  duration: string;
  keyPoints: string[];
  category: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  title: string;
  lessonId: string;
  questions: QuizQuestion[];
  passingScore: number;
}

export interface Component3D {
  id: string;
  name: string;
  type: 'motherboard' | 'cpu' | 'ram' | 'gpu' | 'psu' | 'storage' | 'fan' | 'case' | 'cable';
  installed: boolean;
  position?: { x: number; y: number; z: number };
  rotation?: { x: number; y: number; z: number };
  requiredBefore?: string[];
  installSteps?: string[];
}
