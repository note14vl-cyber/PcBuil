import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonProgressBar,
  IonBadge,
  IonGrid,
  IonRow,
  IonCol,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  videocamOutline,
  helpCircleOutline,
  constructOutline,
  personOutline,
  lockClosedOutline,
  checkmarkCircleOutline,
  trophyOutline,
} from 'ionicons/icons';
import { ProgressService, UserProgress } from '../../services/progress';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonProgressBar,
    IonBadge,
    IonGrid,
    IonRow,
    IonCol,
    CommonModule,
    FormsModule,
  ],
})
export class HomePage implements OnInit {
  progress: UserProgress | null = null;
  overallProgress = 0;

  constructor(
    private progressService: ProgressService,
    private router: Router
  ) {
    addIcons({
      videocamOutline,
      helpCircleOutline,
      constructOutline,
      personOutline,
      lockClosedOutline,
      checkmarkCircleOutline,
      trophyOutline,
    });
  }

  async ngOnInit() {
    await this.loadProgress();
  }

  async ionViewWillEnter() {
    await this.loadProgress();
  }

  async loadProgress() {
    this.progress = await this.progressService.getProgress();
    this.calculateOverallProgress();
  }

  calculateOverallProgress() {
    if (!this.progress) return;

    let completed = 0;
    if (this.progress.level1Completed) completed += 33;
    if (this.progress.level2Completed) completed += 33;
    if (this.progress.level3Completed) completed += 34;

    this.overallProgress = completed / 100;
  }

  navigateToLevel(level: number) {
    if (!this.progress) return;

    if (level > this.progress.currentLevel) {
      return; // Level is locked
    }

    switch (level) {
      case 1:
        this.router.navigate(['/level1-videos']);
        break;
      case 2:
        this.router.navigate(['/level2-quiz']);
        break;
      case 3:
        this.router.navigate(['/level3-simulator']);
        break;
    }
  }

  navigateToProfile() {
    this.router.navigate(['/profile']);
  }

  isLevelUnlocked(level: number): boolean {
    return this.progress ? level <= this.progress.currentLevel : false;
  }

  isLevelCompleted(level: number): boolean {
    if (!this.progress) return false;

    switch (level) {
      case 1:
        return this.progress.level1Completed;
      case 2:
        return this.progress.level2Completed;
      case 3:
        return this.progress.level3Completed;
      default:
        return false;
    }
  }
}
