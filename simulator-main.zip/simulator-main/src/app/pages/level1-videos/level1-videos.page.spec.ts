import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Level1VideosPage } from './level1-videos.page';

describe('Level1VideosPage', () => {
  let component: Level1VideosPage;
  let fixture: ComponentFixture<Level1VideosPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Level1VideosPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
