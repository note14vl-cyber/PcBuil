import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButtons,
  IonBackButton,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonBadge,
  IonList,
  IonItem,
  IonLabel,
  IonProgressBar,
  IonChip,
  IonModal,
  IonText,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  playCircleOutline,
  checkmarkCircleOutline,
  timeOutline,
  chevronForwardOutline,
  closeOutline,
  bookmarkOutline,
} from 'ionicons/icons';
import { DataService } from '../../services/data.service';
import { ProgressService } from '../../services/progress';
import { VideoLesson } from '../../models/interfaces';

@Component({
  selector: 'app-level1-videos',
  templateUrl: './level1-videos.page.html',
  styleUrls: ['./level1-videos.page.scss'],
  standalone: true,
  imports: [
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonButtons,
    IonBackButton,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonBadge,
    IonList,
    IonItem,
    IonLabel,
    IonProgressBar,
    IonChip,
    IonModal,
    IonText,
    CommonModule,
    FormsModule,
  ],
})
export class Level1VideosPage implements OnInit {
  lessons: VideoLesson[] = [];
  watchedVideos: string[] = [];
  selectedLesson: VideoLesson | null = null;
  isModalOpen = false;
  safeVideoUrl: SafeResourceUrl | null = null;
  progress = 0;

  constructor(
    private dataService: DataService,
    private progressService: ProgressService,
    private router: Router,
    private sanitizer: DomSanitizer
  ) {
    addIcons({
      playCircleOutline,
      checkmarkCircleOutline,
      timeOutline,
      chevronForwardOutline,
      closeOutline,
      bookmarkOutline,
    });
  }

  async ngOnInit() {
    this.lessons = this.dataService.getVideoLessons();
    await this.loadProgress();
  }

  async loadProgress() {
    const userProgress = await this.progressService.getProgress();
    this.watchedVideos = userProgress.videosWatched;
    this.calculateProgress();
  }

  calculateProgress() {
    this.progress = this.watchedVideos.length / this.lessons.length;
  }

  isVideoWatched(lessonId: string): boolean {
    return this.watchedVideos.includes(lessonId);
  }

  openVideo(lesson: VideoLesson) {
    this.selectedLesson = lesson;
    this.safeVideoUrl = this.sanitizer.bypassSecurityTrustResourceUrl(
      lesson.videoUrl
    );
    this.isModalOpen = true;
  }

  closeModal() {
    this.isModalOpen = false;
    this.selectedLesson = null;
    this.safeVideoUrl = null;
  }

  async markAsWatched() {
    if (this.selectedLesson) {
      await this.progressService.markVideoWatched(this.selectedLesson.id);
      await this.loadProgress();
      
      // Check if all videos are watched
      if (this.watchedVideos.length === this.lessons.length) {
        await this.progressService.unlockLevel(2);
      }
    }
  }

  async completeLevel() {
    await this.progressService.unlockLevel(2);
    this.router.navigate(['/home']);
  }

  getLessonsByCategory(category: string): VideoLesson[] {
    return this.lessons.filter((lesson) => lesson.category === category);
  }

  getCategories(): string[] {
    const categories = this.lessons.map((lesson) => lesson.category);
    return [...new Set(categories)];
  }

  getCategoryProgress(category: string): number {
    const categoryLessons = this.getLessonsByCategory(category);
    const watchedInCategory = categoryLessons.filter((lesson) =>
      this.isVideoWatched(lesson.id)
    ).length;
    return watchedInCategory / categoryLessons.length;
  }
}
