import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Level2QuizPage } from './level2-quiz.page';

describe('Level2QuizPage', () => {
  let component: Level2QuizPage;
  let fixture: ComponentFixture<Level2QuizPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Level2QuizPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
