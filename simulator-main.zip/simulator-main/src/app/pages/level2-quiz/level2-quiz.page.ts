import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButtons,
  IonBackButton,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonBadge,
  IonList,
  IonItem,
  IonLabel,
  IonRadioGroup,
  IonRadio,
  IonProgressBar,
  IonText,
  IonChip,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  checkmarkCircleOutline,
  closeCircleOutline,
  refreshOutline,
  trophyOutline,
  alertCircleOutline,
  chevronForwardOutline,
  chevronBackOutline,
} from 'ionicons/icons';
import { DataService } from '../../services/data.service';
import { ProgressService } from '../../services/progress';
import { Quiz, QuizQuestion } from '../../models/interfaces';

@Component({
  selector: 'app-level2-quiz',
  templateUrl: './level2-quiz.page.html',
  styleUrls: ['./level2-quiz.page.scss'],
  standalone: true,
  imports: [
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonButtons,
    IonBackButton,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonBadge,
    IonList,
    IonItem,
    IonLabel,
    IonRadioGroup,
    IonRadio,
    IonProgressBar,
    IonText,
    IonChip,
    CommonModule,
    FormsModule,
  ],
})
export class Level2QuizPage implements OnInit {
  quizzes: Quiz[] = [];
  selectedQuiz: Quiz | null = null;
  currentQuestionIndex = 0;
  userAnswers: { [questionId: string]: number } = {};
  showResults = false;
  score = 0;
  quizStarted = false;
  answeredQuestions: Set<string> = new Set();
  questionFeedback: { [questionId: string]: boolean } = {};

  constructor(
    private dataService: DataService,
    private progressService: ProgressService,
    private router: Router
  ) {
    addIcons({
      checkmarkCircleOutline,
      closeCircleOutline,
      refreshOutline,
      trophyOutline,
      alertCircleOutline,
      chevronForwardOutline,
      chevronBackOutline,
    });
  }

  ngOnInit() {
    this.quizzes = this.dataService.getQuizzes();
  }

  startQuiz(quiz: Quiz) {
    this.selectedQuiz = quiz;
    this.currentQuestionIndex = 0;
    this.userAnswers = {};
    this.showResults = false;
    this.quizStarted = true;
    this.answeredQuestions.clear();
    this.questionFeedback = {};
    this.shuffleQuestions();
  }

  shuffleQuestions() {
    if (this.selectedQuiz) {
      // Shuffle questions for variety
      this.selectedQuiz.questions = this.selectedQuiz.questions.sort(
        () => Math.random() - 0.5
      );
    }
  }

  get currentQuestion(): QuizQuestion | null {
    if (!this.selectedQuiz) return null;
    return this.selectedQuiz.questions[this.currentQuestionIndex];
  }

  get progress(): number {
    if (!this.selectedQuiz) return 0;
    return (this.currentQuestionIndex + 1) / this.selectedQuiz.questions.length;
  }

  selectAnswer(questionId: string, answerIndex: number) {
    this.userAnswers[questionId] = answerIndex;
  }

  submitAnswer() {
    if (!this.currentQuestion) return;

    const questionId = this.currentQuestion.id;
    const userAnswer = this.userAnswers[questionId];

    if (userAnswer === undefined) return;

    const isCorrect = userAnswer === this.currentQuestion.correctAnswer;
    this.questionFeedback[questionId] = isCorrect;
    this.answeredQuestions.add(questionId);
  }

  nextQuestion() {
    if (!this.selectedQuiz) return;

    if (this.currentQuestionIndex < this.selectedQuiz.questions.length - 1) {
      this.currentQuestionIndex++;
    }
  }

  previousQuestion() {
    if (this.currentQuestionIndex > 0) {
      this.currentQuestionIndex--;
    }
  }

  async finishQuiz() {
    if (!this.selectedQuiz) return;

    this.calculateScore();
    await this.saveScore(); // Save score and unlock Level 3 if passed
    this.showResults = true;
  }

  calculateScore() {
    if (!this.selectedQuiz) return;

    let correct = 0;
    this.selectedQuiz.questions.forEach((question) => {
      if (this.userAnswers[question.id] === question.correctAnswer) {
        correct++;
      }
    });

    this.score = (correct / this.selectedQuiz.questions.length) * 100;
  }

  async saveScore() {
    if (!this.selectedQuiz) return;

    await this.progressService.saveQuizScore(this.selectedQuiz.id, this.score);

    if (this.score >= (this.selectedQuiz.passingScore || 70)) {
      await this.progressService.unlockLevel(3);
    }
  }

  async retakeQuiz() {
    if (this.selectedQuiz) {
      this.startQuiz(this.selectedQuiz);
    }
  }

  backToQuizList() {
    this.selectedQuiz = null;
    this.quizStarted = false;
    this.showResults = false;
  }

  goToSimulator() {
    this.router.navigate(['/level3-simulator']);
  }

  goHome() {
    this.router.navigate(['/home']);
  }

  isQuestionAnswered(questionId: string): boolean {
    return this.answeredQuestions.has(questionId);
  }

  getQuestionFeedback(questionId: string): boolean | null {
    return this.questionFeedback[questionId] ?? null;
  }

  isAnswerCorrect(questionId: string, answerIndex: number): boolean {
    const question = this.selectedQuiz?.questions.find((q) => q.id === questionId);
    return question ? answerIndex === question.correctAnswer : false;
  }

  isAnswerSelected(questionId: string, answerIndex: number): boolean {
    return this.userAnswers[questionId] === answerIndex;
  }

  canProceedToNext(): boolean {
    return this.currentQuestion ? this.isQuestionAnswered(this.currentQuestion.id) : false;
  }

  isLastQuestion(): boolean {
    if (!this.selectedQuiz) return false;
    return this.currentQuestionIndex === this.selectedQuiz.questions.length - 1;
  }

  allQuestionsAnswered(): boolean {
    if (!this.selectedQuiz) return false;
    return this.answeredQuestions.size === this.selectedQuiz.questions.length;
  }
}
