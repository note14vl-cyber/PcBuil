import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Level3SimulatorPage } from './level3-simulator.page';

describe('Level3SimulatorPage', () => {
  let component: Level3SimulatorPage;
  let fixture: ComponentFixture<Level3SimulatorPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Level3SimulatorPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
