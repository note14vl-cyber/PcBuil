import { Component, OnInit, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButtons,
  IonBackButton,
  IonButton,
  IonIcon,
  IonProgressBar,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonList,
  IonItem,
  IonLabel,
  IonBadge,
  AlertController,
  ToastController,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  checkmarkCircleOutline,
  cubeOutline,
  refreshOutline,
  homeOutline,
  informationCircleOutline,
  lockClosedOutline,
  flashOutline,
  warningOutline,
  checkmarkOutline,
  closeOutline,
} from 'ionicons/icons';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { ProgressService } from '../../services/progress';

interface PCComponent {
  id: string;
  name: string;
  type: string;
  installed: boolean;
  screwed: boolean;
  mesh?: THREE.Group;
  targetPosition: THREE.Vector3;
  targetRotation: THREE.Euler;
  description: string;
  requiredBefore?: string[];
  ghostMesh?: THREE.Group;
  highlightMesh?: THREE.Mesh;
  screwPositions?: THREE.Vector3[];
  screwsMesh?: THREE.Group[];
  requiresScrews?: boolean;
  slotType?: string;
  cables?: { from: string; to: string; connected: boolean }[];
}

interface Cable {
  id: string;
  name: string;
  from: string;
  to: string;
  connected: boolean;
  mesh?: THREE.Line;
}

@Component({
  selector: 'app-level3-simulator',
  templateUrl: './level3-simulator.page.html',
  styleUrls: ['./level3-simulator.page.scss'],
  standalone: true,
  imports: [
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonButtons,
    IonBackButton,
    IonButton,
    IonIcon,
    IonProgressBar,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonList,
    IonItem,
    IonLabel,
    IonBadge,
    CommonModule,
    FormsModule,
  ],
})
export class Level3SimulatorPage implements OnInit, OnDestroy {
  @ViewChild('rendererContainer', { static: true }) rendererContainer!: ElementRef;

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private controls!: OrbitControls;
  private raycaster!: THREE.Raycaster;
  private mouse!: THREE.Vector2;
  private selectedComponent: PCComponent | null = null;
  private draggedObject: THREE.Group | null = null;
  private animationId: number = 0;
  private dragPlane!: THREE.Plane;
  private offset = new THREE.Vector3();
  private intersection = new THREE.Vector3();
  private clock = new THREE.Clock();
  private fanMeshes: THREE.Mesh[] = [];
  private rgbLights: THREE.PointLight[] = [];
  private boundaryBox: THREE.LineSegments | null = null;
  private isDragging = false;
  private dragStartPosition = new THREE.Vector3();

  components: PCComponent[] = [];
  cables: Cable[] = [];
  progress = 0;
  isComplete = false;
  isPoweredOn = false;
  currentMode: 'install' | 'screw' | 'cable' = 'install';
  showInstructions = true;
  panelCollapsed = false;
  currentHint = '';

  constructor(
    private progressService: ProgressService,
    private router: Router,
    private alertController: AlertController,
    private toastController: ToastController
  ) {
    addIcons({
      checkmarkCircleOutline,
      cubeOutline,
      refreshOutline,
      homeOutline,
      informationCircleOutline,
      lockClosedOutline,
      flashOutline,
      warningOutline,
      checkmarkOutline,
      closeOutline,
    });
  }

  ngOnInit() {
    this.initComponents();
    this.initCables();
    this.initThreeJS();
    this.createScene();
    this.animate();
    this.setupEventListeners();
  }

  ngOnDestroy() {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
    if (this.controls) {
      this.controls.dispose();
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  initComponents() {
    this.components = [
      {
        id: 'case',
        name: 'PC Case',
        type: 'case',
        installed: false,
        screwed: false,
        targetPosition: new THREE.Vector3(0, 1.25, 0),
        targetRotation: new THREE.Euler(0, 0, 0),
        description: 'ATX Mid-Tower Case',
        requiresScrews: false,
        slotType: 'base',
      },
      {
        id: 'psu',
        name: 'Power Supply (750W)',
        type: 'psu',
        installed: false,
        screwed: false,
        targetPosition: new THREE.Vector3(0, -1.15, -1.8),
        targetRotation: new THREE.Euler(0, 0, 0),
        description: '80+ Gold PSU',
        requiredBefore: ['case'],
        requiresScrews: true,
        slotType: 'psu_mount',
        screwPositions: [
          new THREE.Vector3(-1.4, -1.6, -1.8),
          new THREE.Vector3(1.4, -1.6, -1.8),
          new THREE.Vector3(-1.4, -1.6, -2.8),
          new THREE.Vector3(1.4, -1.6, -2.8),
        ],
      },
      {
        id: 'motherboard',
        name: 'Motherboard (ATX)',
        type: 'motherboard',
        installed: false,
        screwed: false,
        targetPosition: new THREE.Vector3(0, 2.0, 0),
        targetRotation: new THREE.Euler(-Math.PI / 2, 0, 0),
        description: 'ATX Gaming Motherboard',
        requiredBefore: ['case'],
        requiresScrews: true,
        slotType: 'motherboard_mount',
        screwPositions: [
          new THREE.Vector3(-1.2, 0.5, -1.2),
          new THREE.Vector3(1.2, 0.5, -1.2),
          new THREE.Vector3(-1.2, 0.5, 1.2),
          new THREE.Vector3(1.2, 0.5, 1.2),
          new THREE.Vector3(0, 0.5, 0),
        ],
      },
      {
        id: 'cpu',
        name: 'CPU (Intel i7)',
        type: 'cpu',
        installed: false,
        screwed: false,
        targetPosition: new THREE.Vector3(0, 2.2, -0.6),
        targetRotation: new THREE.Euler(0, 0, 0),
        description: 'LGA1700 Processor',
        requiredBefore: ['motherboard'],
        requiresScrews: false,
        slotType: 'cpu_socket',
      },
      {
        id: 'ram',
        name: 'RAM (16GB DDR5)',
        type: 'ram',
        installed: false,
        screwed: false,
        targetPosition: new THREE.Vector3(0.9, 2.2, 0),
        targetRotation: new THREE.Euler(0, 0, Math.PI / 2),
        description: 'DDR5 Memory Module',
        requiredBefore: ['motherboard'],
        requiresScrews: false,
        slotType: 'dimm_slot',
      },
      {
        id: 'cooler',
        name: 'CPU Cooler (AIO)',
        type: 'cooler',
        installed: false,
        screwed: false,
        targetPosition: new THREE.Vector3(0, 3.2, -0.6),
        targetRotation: new THREE.Euler(0, 0, 0),
        description: 'Liquid Cooling System',
        requiredBefore: ['cpu'],
        requiresScrews: true,
        slotType: 'cpu_cooler',
        screwPositions: [
          new THREE.Vector3(-0.4, 1.3, -0.4),
          new THREE.Vector3(0.4, 1.3, -0.4),
          new THREE.Vector3(-0.4, 1.3, -0.8),
          new THREE.Vector3(0.4, 1.3, -0.8),
        ],
      },
      {
        id: 'gpu',
        name: 'Graphics Card (RTX 4070)',
        type: 'gpu',
        installed: false,
        screwed: false,
        targetPosition: new THREE.Vector3(-0.3, 3.05, 0.7),
        targetRotation: new THREE.Euler(0, Math.PI / 2, Math.PI / 2),
        description: 'NVIDIA RTX GPU',
        requiredBefore: ['motherboard'],
        requiresScrews: true,
        slotType: 'pcie_x16',
        screwPositions: [
          new THREE.Vector3(-0.3, 1.2, 2.0),
        ],
      },
      {
        id: 'storage',
        name: 'M.2 SSD (1TB)',
        type: 'storage',
        installed: false,
        screwed: false,
        targetPosition: new THREE.Vector3(0, 2.12, 0.9),
        targetRotation: new THREE.Euler(0, 0, 0),
        description: 'NVMe Storage',
        requiredBefore: ['motherboard'],
        requiresScrews: true,
        slotType: 'm2_slot',
        screwPositions: [
          new THREE.Vector3(0, 0.58, 1.8),
        ],
      },
    ];
  }

  initCables() {
    this.cables = [
      {
        id: 'cable_24pin',
        name: '24-Pin ATX Power',
        from: 'psu',
        to: 'motherboard',
        connected: false,
      },
      {
        id: 'cable_8pin_cpu',
        name: '8-Pin CPU Power',
        from: 'psu',
        to: 'cpu',
        connected: false,
      },
      {
        id: 'cable_pcie',
        name: 'PCIe Power (8-Pin)',
        from: 'psu',
        to: 'gpu',
        connected: false,
      },
    ];
  }

  initThreeJS() {
    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x2a3a4a);
    this.scene.fog = new THREE.FogExp2(0x2a3a4a, 0.005);

    // Camera
    const container = this.rendererContainer.nativeElement;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || (window.innerHeight - 200);
    const aspect = width / height;
    
    this.camera = new THREE.PerspectiveCamera(55, aspect, 0.1, 1000);
    this.camera.position.set(10, 8, 10);
    this.camera.lookAt(0, 0, 0);

    // Renderer with enhanced settings
    this.renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.8;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);

    // Controls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.05;
    this.controls.minDistance = 6;
    this.controls.maxDistance = 25;
    this.controls.maxPolarAngle = Math.PI / 2;
    this.controls.target.set(0, 1, 0);
    this.controls.update();

    // Raycaster
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();
    this.dragPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

    // Professional Lighting Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    this.scene.add(ambientLight);

    // Key light
    const keyLight = new THREE.DirectionalLight(0xffffff, 2.5);
    keyLight.position.set(12, 18, 12);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 4096;
    keyLight.shadow.mapSize.height = 4096;
    keyLight.shadow.camera.near = 0.5;
    keyLight.shadow.camera.far = 60;
    keyLight.shadow.camera.left = -20;
    keyLight.shadow.camera.right = 20;
    keyLight.shadow.camera.top = 20;
    keyLight.shadow.camera.bottom = -20;
    keyLight.shadow.bias = -0.0001;
    this.scene.add(keyLight);

    // Fill lights
    const fillLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    fillLight1.position.set(-12, 8, -12);
    this.scene.add(fillLight1);

    const fillLight2 = new THREE.DirectionalLight(0xffffff, 1.0);
    fillLight2.position.set(12, 6, -12);
    this.scene.add(fillLight2);

    const fillLight3 = new THREE.DirectionalLight(0xffffff, 0.8);
    fillLight3.position.set(0, 10, 12);
    this.scene.add(fillLight3);

    // Rim light
    const rimLight = new THREE.DirectionalLight(0x88bbff, 1.0);
    rimLight.position.set(-8, 4, -8);
    this.scene.add(rimLight);

    // RGB Accent lights (will animate)
    const rgbLight1 = new THREE.PointLight(0xff0088, 0.8, 15);
    rgbLight1.position.set(-6, 2, 4);
    this.scene.add(rgbLight1);
    this.rgbLights.push(rgbLight1);

    const rgbLight2 = new THREE.PointLight(0x00ff88, 0.8, 15);
    rgbLight2.position.set(6, 2, -4);
    this.scene.add(rgbLight2);
    this.rgbLights.push(rgbLight2);

    const rgbLight3 = new THREE.PointLight(0x0088ff, 0.8, 15);
    rgbLight3.position.set(0, 2, 6);
    this.scene.add(rgbLight3);
    this.rgbLights.push(rgbLight3);
  }

  createScene() {
    // Enhanced Platform with metallic finish
    const platformGeo = new THREE.CylinderGeometry(16, 16, 1, 64);
    const platformMat = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.95,
      roughness: 0.15,
      envMapIntensity: 1.5,
    });
    const platform = new THREE.Mesh(platformGeo, platformMat);
    platform.position.y = -2.5;
    platform.receiveShadow = true;
    platform.castShadow = false;
    this.scene.add(platform);

    // Grid with glow effect
    const gridHelper = new THREE.GridHelper(30, 30, 0x00ff88, 0x333333);
    gridHelper.position.y = -1.99;
    gridHelper.material.opacity = 0.3;
    gridHelper.material.transparent = true;
    this.scene.add(gridHelper);

    // Create boundary box indicator
    this.createBoundaryBox();

    // Create all components with enhanced models
    this.components.forEach((component, index) => {
      const mesh = this.createEnhancedComponent(component);
      component.mesh = mesh;

      // Arrange in arc formation
      const angle = (index / this.components.length) * Math.PI * 1.6 - Math.PI * 0.8;
      const radius = 11;
      const x = Math.sin(angle) * radius;
      const y = 1;
      const z = Math.cos(angle) * radius + 4;
      
      mesh.position.set(x, y, z);
      mesh.rotation.y = -angle;

      this.scene.add(mesh);

      // Create ghost indicator
      const ghost = this.createGhostIndicator(component);
      component.ghostMesh = ghost;
      this.scene.add(ghost);

      // Create highlight mesh
      const highlight = this.createHighlightMesh(component);
      component.highlightMesh = highlight;
      this.scene.add(highlight);
    });
  }


  createEnhancedComponent(component: PCComponent): THREE.Group {
    const group = new THREE.Group();
    group.userData['component'] = component;

    switch (component.type) {
      case 'case':
        this.createRealisticCase(group);
        break;
      case 'motherboard':
        this.createRealisticMotherboard(group);
        break;
      case 'cpu':
        this.createRealisticCPU(group);
        break;
      case 'cooler':
        this.createRealisticCooler(group);
        break;
      case 'ram':
        this.createRealisticRAM(group);
        break;
      case 'gpu':
        this.createRealisticGPU(group);
        break;
      case 'psu':
        this.createRealisticPSU(group);
        break;
      case 'storage':
        this.createRealisticStorage(group);
        break;
    }

    // Scale up all components by 1.5x for better visibility
    group.scale.set(1.5, 1.5, 1.5);

    group.castShadow = true;
    group.receiveShadow = true;
    return group;
  }

  // Enhanced component creation methods with PBR materials
  createRealisticCase(group: THREE.Group) {
    // Create an open case with individual panels instead of a solid box
    const panelMat = new THREE.MeshStandardMaterial({
      color: 0x0a0a0a,
      metalness: 0.9,
      roughness: 0.2,
      envMapIntensity: 1.2,
    });

    // Bottom panel
    const bottomGeo = new THREE.BoxGeometry(4, 0.1, 5.5);
    const bottom = new THREE.Mesh(bottomGeo, panelMat);
    bottom.position.y = -2.5;
    bottom.castShadow = true;
    bottom.receiveShadow = true;
    group.add(bottom);

    // Top panel
    const topGeo = new THREE.BoxGeometry(4, 0.1, 5.5);
    const top = new THREE.Mesh(topGeo, panelMat);
    top.position.y = 2.5;
    top.castShadow = true;
    top.receiveShadow = true;
    group.add(top);

    // Back panel
    const backGeo = new THREE.BoxGeometry(4, 5, 0.1);
    const back = new THREE.Mesh(backGeo, panelMat);
    back.position.z = -2.75;
    back.castShadow = true;
    back.receiveShadow = true;
    group.add(back);

    // Front panel
    const frontGeo = new THREE.BoxGeometry(4, 5, 0.1);
    const front = new THREE.Mesh(frontGeo, panelMat);
    front.position.z = 2.75;
    front.castShadow = true;
    front.receiveShadow = true;
    group.add(front);

    // Right side panel (solid)
    const rightGeo = new THREE.BoxGeometry(0.1, 5, 5.5);
    const right = new THREE.Mesh(rightGeo, panelMat);
    right.position.x = -2;
    right.castShadow = true;
    right.receiveShadow = true;
    group.add(right);

    // LEFT SIDE IS OPEN - No panel here so you can see inside!

    // Tempered glass panel (positioned away from case, as if removed)
    const glassGeo = new THREE.BoxGeometry(0.08, 4.8, 5.3);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0x88ccff,
      transmission: 0.98,
      opacity: 0.1,
      transparent: true,
      roughness: 0,
      metalness: 0,
      clearcoat: 1,
      clearcoatRoughness: 0.05,
      ior: 1.5,
      thickness: 0.5,
      envMapIntensity: 2,
    });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    // Position glass panel to the side, as if it's been removed
    glass.position.set(4, 0, 0);
    glass.rotation.y = Math.PI / 8; // Slight angle
    group.add(glass);

    // RGB LED strip inside the case
    const rgbGeo = new THREE.BoxGeometry(0.12, 0.15, 5);
    const rgbMat = new THREE.MeshStandardMaterial({ 
      color: 0x00ff88,
      emissive: 0x00ff88,
      emissiveIntensity: 2,
      metalness: 0,
      roughness: 1,
    });
    const rgb = new THREE.Mesh(rgbGeo, rgbMat);
    rgb.position.set(-1.9, -2.3, 0); // Inside the case
    group.add(rgb);

    // Front I/O panel
    const ioPanelGeo = new THREE.BoxGeometry(0.05, 0.8, 1.5);
    const ioPanelMat = new THREE.MeshStandardMaterial({
      color: 0x222222,
      metalness: 0.7,
      roughness: 0.3,
    });
    const ioPanel = new THREE.Mesh(ioPanelGeo, ioPanelMat);
    ioPanel.position.set(0, 2, 2.78);
    group.add(ioPanel);
  }

  createRealisticMotherboard(group: THREE.Group) {
    // PCB with realistic texture
    const pcbGeo = new THREE.BoxGeometry(3, 0.15, 3);
    const pcbMat = new THREE.MeshStandardMaterial({
      color: 0x1a4a1a,
      roughness: 0.8,
      metalness: 0.1,
      normalScale: new THREE.Vector2(0.5, 0.5),
    });
    const pcb = new THREE.Mesh(pcbGeo, pcbMat);

    // VRM heatsinks with aluminum finish
    const vrmGeo = new THREE.BoxGeometry(0.7, 0.4, 2.4);
    const vrmMat = new THREE.MeshStandardMaterial({
      color: 0xaaaaaa,
      metalness: 0.95,
      roughness: 0.2,
      envMapIntensity: 1.5,
    });
    const vrm1 = new THREE.Mesh(vrmGeo, vrmMat);
    vrm1.position.set(-1.1, 0.28, 0);
    vrm1.castShadow = true;

    const vrm2 = vrm1.clone();
    vrm2.scale.set(0.5, 0.9, 0.45);
    vrm2.position.set(0.6, 0.25, -1.2);

    // PCIe slots with metallic finish
    for (let i = 0; i < 3; i++) {
      const slotGeo = new THREE.BoxGeometry(2, 0.2, 0.1);
      const slotMat = new THREE.MeshStandardMaterial({ 
        color: 0x111111,
        metalness: 0.9,
        roughness: 0.3,
      });
      const slot = new THREE.Mesh(slotGeo, slotMat);
      slot.position.set(0.3, 0.12, 0.6 + i * 0.45);
      slot.castShadow = true;
      group.add(slot);
    }

    // RAM slots
    for (let i = 0; i < 4; i++) {
      const ramSlotGeo = new THREE.BoxGeometry(0.15, 0.25, 1.5);
      const ramSlotMat = new THREE.MeshStandardMaterial({ 
        color: 0x222222,
        metalness: 0.8,
        roughness: 0.4,
      });
      const ramSlot = new THREE.Mesh(ramSlotGeo, ramSlotMat);
      ramSlot.position.set(0.9 + i * 0.18, 0.15, -0.3);
      ramSlot.castShadow = true;
      group.add(ramSlot);
    }

    // Chipset heatsink with logo
    const chipsetGeo = new THREE.BoxGeometry(0.9, 0.3, 0.9);
    const chipset = new THREE.Mesh(chipsetGeo, vrmMat);
    chipset.position.set(0, 0.23, 0.9);
    chipset.castShadow = true;

    // RGB header lights
    const rgbHeaderGeo = new THREE.BoxGeometry(0.3, 0.1, 0.1);
    const rgbHeaderMat = new THREE.MeshStandardMaterial({ 
      color: 0xff0088,
      emissive: 0xff0088,
      emissiveIntensity: 1.5,
      metalness: 0,
      roughness: 1,
    });
    const rgbHeader = new THREE.Mesh(rgbHeaderGeo, rgbHeaderMat);
    rgbHeader.position.set(-1.2, 0.13, 1.3);

    group.add(pcb, vrm1, vrm2, chipset, rgbHeader);
  }

  createRealisticCPU(group: THREE.Group) {
    // IHS (Integrated Heat Spreader) - Chrome finish
    const ihsGeo = new THREE.BoxGeometry(1, 0.15, 1);
    const ihsMat = new THREE.MeshStandardMaterial({
      color: 0xe0e0e0,
      metalness: 1,
      roughness: 0.15,
      envMapIntensity: 2,
    });
    const ihs = new THREE.Mesh(ihsGeo, ihsMat);
    ihs.castShadow = true;

    // CPU Logo (Intel/AMD)
    const logoGeo = new THREE.PlaneGeometry(0.7, 0.7);
    const logoMat = new THREE.MeshStandardMaterial({ 
      color: 0x0066cc,
      emissive: 0x0066cc,
      emissiveIntensity: 0.5,
      metalness: 0,
      roughness: 1,
    });
    const logo = new THREE.Mesh(logoGeo, logoMat);
    logo.rotation.x = -Math.PI / 2;
    logo.position.y = 0.076;

    // Substrate (green PCB)
    const subGeo = new THREE.BoxGeometry(1.05, 0.06, 1.05);
    const subMat = new THREE.MeshStandardMaterial({ 
      color: 0x1a5a1a,
      roughness: 0.9,
    });
    const substrate = new THREE.Mesh(subGeo, subMat);
    substrate.position.y = -0.105;

    // Contact pins (gold)
    const pinsGeo = new THREE.BoxGeometry(0.95, 0.02, 0.95);
    const pinsMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      metalness: 1,
      roughness: 0.2,
    });
    const pins = new THREE.Mesh(pinsGeo, pinsMat);
    pins.position.y = -0.135;

    group.add(ihs, logo, substrate, pins);
  }

  createRealisticCooler(group: THREE.Group) {
    // Heatsink block - Aluminum
    const sinkGeo = new THREE.BoxGeometry(1.2, 1.2, 1.2);
    const sinkMat = new THREE.MeshStandardMaterial({
      color: 0xcccccc,
      metalness: 0.95,
      roughness: 0.25,
      envMapIntensity: 1.5,
    });
    const sink = new THREE.Mesh(sinkGeo, sinkMat);
    sink.castShadow = true;

    // Heat pipes - Copper
    for (let i = 0; i < 5; i++) {
      const pipeGeo = new THREE.CylinderGeometry(0.1, 0.1, 1.5, 16);
      const pipeMat = new THREE.MeshStandardMaterial({
        color: 0xcc6633,
        metalness: 0.95,
        roughness: 0.1,
        envMapIntensity: 1.8,
      });
      const pipe = new THREE.Mesh(pipeGeo, pipeMat);
      pipe.position.set(-0.4 + i * 0.2, 0, 0);
      pipe.castShadow = true;
      group.add(pipe);
    }

    // Fan housing
    const fanHousingGeo = new THREE.CylinderGeometry(0.58, 0.58, 0.18, 32);
    const fanHousingMat = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.4,
      roughness: 0.6,
    });
    const fanHousing = new THREE.Mesh(fanHousingGeo, fanHousingMat);
    fanHousing.rotation.x = Math.PI / 2;
    fanHousing.position.z = 0.69;
    fanHousing.castShadow = true;

    // Fan blades (will spin)
    const bladesGroup = new THREE.Group();
    for (let i = 0; i < 7; i++) {
      const bladeGeo = new THREE.BoxGeometry(0.1, 0.45, 0.03);
      const bladeMat = new THREE.MeshStandardMaterial({ 
        color: 0x333333,
        metalness: 0.3,
        roughness: 0.7,
      });
      const blade = new THREE.Mesh(bladeGeo, bladeMat);
      blade.position.set(
        Math.cos((i / 7) * Math.PI * 2) * 0.28,
        Math.sin((i / 7) * Math.PI * 2) * 0.28,
        0
      );
      blade.rotation.z = (i / 7) * Math.PI * 2 + Math.PI / 4;
      bladesGroup.add(blade);
    }
    bladesGroup.position.z = 0.7;
    this.fanMeshes.push(bladesGroup as any);

    // RGB ring
    const rgbRingGeo = new THREE.TorusGeometry(0.52, 0.04, 16, 32);
    const rgbRingMat = new THREE.MeshStandardMaterial({ 
      color: 0x00ff88,
      emissive: 0x00ff88,
      emissiveIntensity: 2,
      metalness: 0,
      roughness: 1,
    });
    const rgbRing = new THREE.Mesh(rgbRingGeo, rgbRingMat);
    rgbRing.rotation.x = Math.PI / 2;
    rgbRing.position.z = 0.7;

    group.add(sink, fanHousing, bladesGroup, rgbRing);
  }

  createRealisticRAM(group: THREE.Group) {
    // PCB
    const pcbGeo = new THREE.BoxGeometry(0.15, 1, 2.6);
    const pcbMat = new THREE.MeshStandardMaterial({
      color: 0x1a3a1a,
      roughness: 0.9,
    });
    const pcb = new THREE.Mesh(pcbGeo, pcbMat);

    // Heat spreader - Red aluminum
    const heatGeo = new THREE.BoxGeometry(0.18, 1.02, 2.62);
    const heatMat = new THREE.MeshStandardMaterial({
      color: 0xcc0000,
      metalness: 0.85,
      roughness: 0.25,
      envMapIntensity: 1.3,
    });
    const heat = new THREE.Mesh(heatGeo, heatMat);
    heat.castShadow = true;

    // RGB strip on top
    const rgbGeo = new THREE.BoxGeometry(0.2, 0.18, 2.5);
    const rgbMat = new THREE.MeshStandardMaterial({ 
      color: 0x00ff00,
      emissive: 0x00ff00,
      emissiveIntensity: 2,
      metalness: 0,
      roughness: 1,
    });
    const rgb = new THREE.Mesh(rgbGeo, rgbMat);
    rgb.position.y = 0.6;

    // Memory chips
    for (let i = 0; i < 8; i++) {
      const chipGeo = new THREE.BoxGeometry(0.16, 0.22, 0.28);
      const chipMat = new THREE.MeshStandardMaterial({ 
        color: 0x0a0a0a,
        metalness: 0.5,
        roughness: 0.6,
      });
      const chip = new THREE.Mesh(chipGeo, chipMat);
      chip.position.set(0, -0.35 + i * 0.1, 0);
      chip.castShadow = true;
      group.add(chip);
    }

    // Brand logo
    const logoGeo = new THREE.PlaneGeometry(0.15, 0.6);
    const logoMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const logo = new THREE.Mesh(logoGeo, logoMat);
    logo.position.set(0.091, 0.3, 0);
    logo.rotation.y = Math.PI / 2;

    group.add(pcb, heat, rgb, logo);
  }

  createRealisticGPU(group: THREE.Group) {
    // PCB
    const pcbGeo = new THREE.BoxGeometry(0.3, 2.4, 4.8);
    const pcbMat = new THREE.MeshStandardMaterial({
      color: 0x1a3a1a,
      roughness: 0.9,
    });
    const pcb = new THREE.Mesh(pcbGeo, pcbMat);
    pcb.castShadow = true;

    // Shroud - Black plastic
    const shroudGeo = new THREE.BoxGeometry(1, 2.2, 4.6);
    const shroudMat = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      metalness: 0.5,
      roughness: 0.4,
    });
    const shroud = new THREE.Mesh(shroudGeo, shroudMat);
    shroud.position.x = 0.65;
    shroud.castShadow = true;

    // Backplate - Brushed metal
    const backGeo = new THREE.BoxGeometry(0.1, 2.3, 4.7);
    const backMat = new THREE.MeshStandardMaterial({
      color: 0x0a0a0a,
      metalness: 0.9,
      roughness: 0.2,
      envMapIntensity: 1.5,
    });
    const backplate = new THREE.Mesh(backGeo, backMat);
    backplate.position.x = -0.2;
    backplate.castShadow = true;

    // Triple fans
    for (let i = 0; i < 3; i++) {
      const fanGeo = new THREE.CylinderGeometry(0.6, 0.6, 0.15, 32);
      const fanMat = new THREE.MeshStandardMaterial({ 
        color: 0x2a2a2a,
        metalness: 0.3,
        roughness: 0.7,
      });
      const fan = new THREE.Mesh(fanGeo, fanMat);
      fan.rotation.z = Math.PI / 2;
      fan.position.set(1.08, 0, -1.4 + i * 1.4);
      fan.castShadow = true;
      
      // Fan blades
      const bladesGroup = new THREE.Group();
      for (let j = 0; j < 9; j++) {
        const bladeGeo = new THREE.BoxGeometry(0.08, 0.5, 0.02);
        const bladeMat = new THREE.MeshStandardMaterial({ color: 0x1a1a1a });
        const blade = new THREE.Mesh(bladeGeo, bladeMat);
        blade.position.set(
          0,
          Math.cos((j / 9) * Math.PI * 2) * 0.35,
          Math.sin((j / 9) * Math.PI * 2) * 0.35
        );
        blade.rotation.x = (j / 9) * Math.PI * 2;
        bladesGroup.add(blade);
      }
      bladesGroup.position.copy(fan.position);
      bladesGroup.rotation.copy(fan.rotation);
      this.fanMeshes.push(bladesGroup as any);
      group.add(bladesGroup);
      
      group.add(fan);
    }

    // RGB accent strip
    const rgbGeo = new THREE.BoxGeometry(0.95, 0.18, 4.5);
    const rgbMat = new THREE.MeshStandardMaterial({ 
      color: 0x00ff88,
      emissive: 0x00ff88,
      emissiveIntensity: 2.5,
      metalness: 0,
      roughness: 1,
    });
    const rgb = new THREE.Mesh(rgbGeo, rgbMat);
    rgb.position.set(0.65, 1.19, 0);

    // GeForce RTX logo
    const logoGeo = new THREE.PlaneGeometry(1.5, 0.4);
    const logoMat = new THREE.MeshStandardMaterial({ 
      color: 0x76b900,
      emissive: 0x76b900,
      emissiveIntensity: 0.8,
      metalness: 0,
      roughness: 1,
    });
    const logo = new THREE.Mesh(logoGeo, logoMat);
    logo.position.set(1.01, 0, 0);
    logo.rotation.y = Math.PI / 2;

    group.add(pcb, shroud, backplate, rgb, logo);
  }

  createRealisticPSU(group: THREE.Group) {
    // Main body - Black metal
    const bodyGeo = new THREE.BoxGeometry(3.5, 1.8, 3.5);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x0a0a0a,
      metalness: 0.8,
      roughness: 0.3,
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.castShadow = true;

    // Fan grill - Honeycomb pattern
    const grillGeo = new THREE.CylinderGeometry(1.4, 1.4, 0.12, 32);
    const grillMat = new THREE.MeshStandardMaterial({
      color: 0x555555,
      metalness: 0.6,
      roughness: 0.5,
    });
    const grill = new THREE.Mesh(grillGeo, grillMat);
    grill.position.y = 0.96;
    grill.castShadow = true;

    // Fan blades (will spin when powered)
    const bladesGroup = new THREE.Group();
    for (let i = 0; i < 7; i++) {
      const bladeGeo = new THREE.BoxGeometry(0.15, 0.7, 0.04);
      const bladeMat = new THREE.MeshStandardMaterial({ color: 0x2a2a2a });
      const blade = new THREE.Mesh(bladeGeo, bladeMat);
      blade.position.set(
        Math.cos((i / 7) * Math.PI * 2) * 0.45,
        0.97,
        Math.sin((i / 7) * Math.PI * 2) * 0.45
      );
      blade.rotation.y = (i / 7) * Math.PI * 2 + Math.PI / 2;
      bladesGroup.add(blade);
    }
    this.fanMeshes.push(bladesGroup as any);

    // 80+ Gold certification label
    const labelGeo = new THREE.PlaneGeometry(2.2, 1);
    const labelMat = new THREE.MeshStandardMaterial({ 
      color: 0xffd700,
      emissive: 0xffd700,
      emissiveIntensity: 0.3,
      metalness: 0,
      roughness: 1,
    });
    const label = new THREE.Mesh(labelGeo, labelMat);
    label.rotation.x = -Math.PI / 2;
    label.position.y = 0.91;

    // Power LED (will glow when on)
    const ledGeo = new THREE.SphereGeometry(0.08, 16, 16);
    const ledMat = new THREE.MeshStandardMaterial({ 
      color: 0x00ff00,
      emissive: 0x00ff00,
      emissiveIntensity: 0,
      metalness: 0,
      roughness: 1,
    });
    const led = new THREE.Mesh(ledGeo, ledMat);
    led.position.set(1.6, 0, 1.6);
    led.userData['isPowerLED'] = true;

    group.add(body, grill, bladesGroup, label, led);
  }

  createRealisticStorage(group: THREE.Group) {
    // M.2 PCB
    const pcbGeo = new THREE.BoxGeometry(0.5, 0.08, 2);
    const pcbMat = new THREE.MeshStandardMaterial({
      color: 0x1a3a1a,
      roughness: 0.9,
    });
    const pcb = new THREE.Mesh(pcbGeo, pcbMat);
    pcb.castShadow = true;

    // Controller chip
    const chipGeo = new THREE.BoxGeometry(0.4, 0.1, 0.6);
    const chipMat = new THREE.MeshStandardMaterial({ 
      color: 0x0a0a0a,
      metalness: 0.6,
      roughness: 0.4,
    });
    const chip = new THREE.Mesh(chipGeo, chipMat);
    chip.position.set(0, 0.09, -0.5);
    chip.castShadow = true;

    // NAND flash chips
    for (let i = 0; i < 4; i++) {
      const nandGeo = new THREE.BoxGeometry(0.4, 0.08, 0.3);
      const nand = new THREE.Mesh(nandGeo, chipMat);
      nand.position.set(0, 0.08, 0.15 + i * 0.35);
      nand.castShadow = true;
      group.add(nand);
    }

    // Brand label with metallic finish
    const labelGeo = new THREE.PlaneGeometry(0.45, 1.8);
    const labelMat = new THREE.MeshStandardMaterial({ 
      color: 0x0088ff,
      emissive: 0x0088ff,
      emissiveIntensity: 0.5,
      metalness: 0.7,
      roughness: 0.3,
    });
    const label = new THREE.Mesh(labelGeo, labelMat);
    label.rotation.x = -Math.PI / 2;
    label.position.y = 0.041;

    // Heatsink (optional, modern M.2 SSDs have this)
    const heatsinkGeo = new THREE.BoxGeometry(0.52, 0.15, 2.02);
    const heatsinkMat = new THREE.MeshStandardMaterial({
      color: 0x888888,
      metalness: 0.95,
      roughness: 0.2,
    });
    const heatsink = new THREE.Mesh(heatsinkGeo, heatsinkMat);
    heatsink.position.y = 0.115;
    heatsink.castShadow = true;

    group.add(pcb, chip, label, heatsink);
  }

  createGhostIndicator(component: PCComponent): THREE.Group {
    const ghost = new THREE.Group();
    const size = new THREE.Vector3();
    
    // Set size based on component type
    switch (component.type) {
      case 'case':
        size.set(4, 5, 5.5);
        break;
      case 'motherboard':
        size.set(3, 0.15, 3);
        break;
      case 'cpu':
        size.set(1, 0.15, 1);
        break;
      case 'cooler':
        size.set(1.2, 1.2, 1.2);
        break;
      case 'ram':
        size.set(0.18, 1, 2.6);
        break;
      case 'gpu':
        size.set(1, 2.4, 4.8);
        break;
      case 'psu':
        size.set(3.5, 1.8, 3.5);
        break;
      case 'storage':
        size.set(0.5, 0.08, 2);
        break;
    }
    
    // Wireframe ghost
    const ghostGeo = new THREE.BoxGeometry(size.x, size.y, size.z);
    const ghostMat = new THREE.MeshBasicMaterial({
      color: 0x00ff88,
      transparent: true,
      opacity: 0.3,
      wireframe: true,
    });
    const ghostMesh = new THREE.Mesh(ghostGeo, ghostMat);
    ghost.add(ghostMesh);

    // Add solid ghost for better visibility
    const solidGhostMat = new THREE.MeshStandardMaterial({
      color: 0x00ff88,
      transparent: true,
      opacity: 0.15,
      emissive: 0x00ff88,
      emissiveIntensity: 0.3,
    });
    const solidGhost = new THREE.Mesh(ghostGeo.clone(), solidGhostMat);
    ghost.add(solidGhost);

    ghost.position.copy(component.targetPosition);
    ghost.rotation.copy(component.targetRotation);
    ghost.visible = false;
    ghost.userData['pulsing'] = true;
    
    // Scale to match component size (1.5x)
    ghost.scale.set(1.5, 1.5, 1.5);

    return ghost;
  }

  createHighlightMesh(component: PCComponent): THREE.Mesh {
    const geo = new THREE.SphereGeometry(0.3, 16, 16);
    const mat = new THREE.MeshBasicMaterial({
      color: 0x00ff88,
      transparent: true,
      opacity: 0,
    });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.visible = false;
    return mesh;
  }

  createBoundaryBox() {
    const caseBounds = {
      minX: -1.8, maxX: 1.8,
      minY: -2.3, maxY: 2.3,
      minZ: -2.5, maxZ: 2.5
    };

    const geometry = new THREE.BoxGeometry(
      caseBounds.maxX - caseBounds.minX,
      caseBounds.maxY - caseBounds.minY,
      caseBounds.maxZ - caseBounds.minZ
    );
    
    const edges = new THREE.EdgesGeometry(geometry);
    const material = new THREE.LineBasicMaterial({ 
      color: 0x00ff88,
      transparent: true,
      opacity: 0,
      linewidth: 2
    });
    
    this.boundaryBox = new THREE.LineSegments(edges, material);
    this.boundaryBox.position.set(0, 0, 0);
    this.scene.add(this.boundaryBox);
  }


  setupEventListeners() {
    const canvas = this.renderer.domElement;
    canvas.addEventListener('pointerdown', (e) => this.onPointerDown(e));
    canvas.addEventListener('pointermove', (e) => this.onPointerMove(e));
    canvas.addEventListener('pointerup', () => this.onPointerUp());
    window.addEventListener('resize', () => this.onWindowResize());
  }

  onPointerDown(event: PointerEvent) {
    this.updateMousePosition(event.clientX, event.clientY);
    this.raycaster.setFromCamera(this.mouse, this.camera);

    const intersects = this.raycaster.intersectObjects(this.scene.children, true);

    for (const intersect of intersects) {
      let obj = intersect.object;
      while (obj.parent && obj.parent !== this.scene) {
        obj = obj.parent;
      }

      if (obj.userData['component']) {
        const component = obj.userData['component'] as PCComponent;
        
        if (!component.installed) {
          if (!this.checkDependencies(component)) {
            return;
          }

          this.controls.enabled = false;
          this.draggedObject = obj as THREE.Group;
          this.selectedComponent = component;
          this.isDragging = true;
          this.dragStartPosition.copy(obj.position);

          // Show ghost mesh with animation
          if (component.ghostMesh) {
            component.ghostMesh.visible = true;
          }

          // Show boundary box when dragging
          if (this.boundaryBox) {
            (this.boundaryBox.material as THREE.LineBasicMaterial).opacity = 0.2;
          }

          // Make component semi-transparent while dragging
          this.setComponentOpacity(obj as THREE.Group, 0.7);

          this.raycaster.ray.intersectPlane(this.dragPlane, this.intersection);
          this.offset.set(0, 0, 0);
          
          // Update hint
          this.currentHint = `Drag ${component.name} to the highlighted position`;
          break;
        }
      }
    }
  }

  onPointerMove(event: PointerEvent) {
    this.updateMousePosition(event.clientX, event.clientY);

    if (this.draggedObject && this.selectedComponent) {
      this.raycaster.setFromCamera(this.mouse, this.camera);
      this.raycaster.ray.intersectPlane(this.dragPlane, this.intersection);
      
      // Center component on cursor
      this.draggedObject.position.copy(this.intersection.sub(this.offset));
      
      // Constrain components to stay inside the PC case boundaries
      const caseBounds = {
        minX: -1.8, maxX: 1.8,
        minY: -2.3, maxY: 2.3,
        minZ: -2.5, maxZ: 2.5
      };
      
      // Clamp position within case boundaries
      this.draggedObject.position.x = Math.max(caseBounds.minX, Math.min(caseBounds.maxX, this.draggedObject.position.x));
      this.draggedObject.position.y = Math.max(caseBounds.minY, Math.min(caseBounds.maxY, this.draggedObject.position.y));
      this.draggedObject.position.z = Math.max(caseBounds.minZ, Math.min(caseBounds.maxZ, this.draggedObject.position.z));
      
      // Enhanced magnetic snapping
      const distanceToTarget = this.draggedObject.position.distanceTo(this.selectedComponent.targetPosition);
      const snapDistance = 3.0;
      const closeSnapDistance = 1.5;
      const veryCloseDistance = 0.8;
      
      if (distanceToTarget < snapDistance) {
        // Progressive snap strength
        const snapStrength = 1 - (distanceToTarget / snapDistance);
        const snapPower = Math.pow(snapStrength, 1.5); // Exponential for stronger pull when close
        
        // Smooth magnetic pull
        this.draggedObject.position.lerp(this.selectedComponent.targetPosition, snapPower * 0.4);
        
        // Rotation snapping
        if (distanceToTarget < closeSnapDistance) {
          const rotationStrength = 1 - (distanceToTarget / closeSnapDistance);
          this.draggedObject.rotation.x += (this.selectedComponent.targetRotation.x - this.draggedObject.rotation.x) * rotationStrength * 0.3;
          this.draggedObject.rotation.y += (this.selectedComponent.targetRotation.y - this.draggedObject.rotation.y) * rotationStrength * 0.3;
          this.draggedObject.rotation.z += (this.selectedComponent.targetRotation.z - this.draggedObject.rotation.z) * rotationStrength * 0.3;
        }
        
        // Enhanced visual feedback
        if (this.selectedComponent.ghostMesh) {
          // Update both ghost meshes
          this.selectedComponent.ghostMesh.children.forEach((child, index) => {
            if (child instanceof THREE.Mesh) {
              const mat = child.material as THREE.MeshBasicMaterial | THREE.MeshStandardMaterial;
              if (index === 0) { // Wireframe
                mat.opacity = 0.3 + (snapStrength * 0.5);
              } else { // Solid
                mat.opacity = 0.15 + (snapStrength * 0.25);
                if ('emissiveIntensity' in mat) {
                  mat.emissiveIntensity = 0.3 + (snapStrength * 0.7);
                }
              }
            }
          });
        }
        
        // Update hint based on distance
        if (distanceToTarget < veryCloseDistance) {
          this.currentHint = '✓ Release to install!';
        } else {
          this.currentHint = `↗ Getting closer... (${distanceToTarget.toFixed(1)}m)`;
        }
      } else {
        // Reset ghost opacity when far
        if (this.selectedComponent.ghostMesh) {
          this.selectedComponent.ghostMesh.children.forEach((child, index) => {
            if (child instanceof THREE.Mesh) {
              const mat = child.material as THREE.MeshBasicMaterial | THREE.MeshStandardMaterial;
              if (index === 0) {
                mat.opacity = 0.3;
              } else {
                mat.opacity = 0.15;
                if ('emissiveIntensity' in mat) {
                  mat.emissiveIntensity = 0.3;
                }
              }
            }
          });
        }
        this.currentHint = `Move ${this.selectedComponent.name} to the highlighted area`;
      }
    }
  }

  async onPointerUp() {
    if (this.draggedObject && this.selectedComponent) {
      const wasInstalled = this.selectedComponent.installed;
      
      await this.checkInstallation(this.draggedObject, this.selectedComponent);
      
      // Hide ghost mesh
      if (this.selectedComponent.ghostMesh) {
        this.selectedComponent.ghostMesh.visible = false;
      }
      
      // Restore opacity if not installed
      if (!this.selectedComponent.installed) {
        this.setComponentOpacity(this.draggedObject, 1.0);
      }
      
      // Hide boundary box
      if (this.boundaryBox) {
        (this.boundaryBox.material as THREE.LineBasicMaterial).opacity = 0;
      }
    }

    this.isDragging = false;
    this.draggedObject = null;
    this.selectedComponent = null;
    this.controls.enabled = true;
    this.currentHint = '';
  }

  setComponentOpacity(group: THREE.Group, opacity: number) {
    group.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        const materials = Array.isArray(child.material) ? child.material : [child.material];
        materials.forEach(mat => {
          if (mat instanceof THREE.MeshStandardMaterial || 
              mat instanceof THREE.MeshPhysicalMaterial ||
              mat instanceof THREE.MeshBasicMaterial) {
            mat.transparent = opacity < 1.0;
            mat.opacity = opacity;
          }
        });
      }
    });
  }

  updateMousePosition(clientX: number, clientY: number) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;
  }

  async checkDependencies(component: PCComponent): Promise<boolean> {
    if (!component.requiredBefore) return true;

    const missing = component.requiredBefore.filter(id => {
      const dep = this.components.find(c => c.id === id);
      return dep && !dep.installed;
    });

    if (missing.length > 0) {
      const names = missing.map(id => 
        this.components.find(c => c.id === id)?.name || id
      ).join(', ');

      await this.showToast(`⚠️ Install ${names} first!`, 'warning');
      return false;
    }
    return true;
  }

  async checkInstallation(obj: THREE.Group, component: PCComponent) {
    const distance = obj.position.distanceTo(component.targetPosition);

    if (distance < 1.8) {
      // Snap to position with animation
      obj.position.copy(component.targetPosition);
      obj.rotation.copy(component.targetRotation);
      component.installed = true;
      
      this.createInstallParticles(component.targetPosition);
      this.updateProgress();

      await this.showToast(`✓ ${component.name} installed!`, 'success');
      
      // Check if screws are needed
      if (component.requiresScrews) {
        await this.showToast(`🔧 Now secure with screws`, 'primary');
      }
    } else {
      // Return to inventory
      const index = this.components.indexOf(component);
      const angle = (index / this.components.length) * Math.PI * 1.6 - Math.PI * 0.8;
      const radius = 11;
      obj.position.set(
        Math.sin(angle) * radius,
        1,
        Math.cos(angle) * radius + 4
      );
      obj.rotation.y = -angle;
    }
  }

  createInstallParticles(position: THREE.Vector3) {
    const particleCount = 40;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);
    const sizes = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 2;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 2;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 2;

      colors[i * 3] = 0;
      colors[i * 3 + 1] = 1;
      colors[i * 3 + 2] = 0.5;
      
      sizes[i] = Math.random() * 0.3 + 0.1;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

    const material = new THREE.PointsMaterial({
      size: 0.2,
      vertexColors: true,
      transparent: true,
      opacity: 1,
      blending: THREE.AdditiveBlending,
    });

    const particles = new THREE.Points(geometry, material);
    particles.position.copy(position);
    this.scene.add(particles);

    setTimeout(() => this.scene.remove(particles), 1200);
  }

  updateProgress() {
    const installed = this.components.filter(c => c.installed).length;
    this.progress = installed / this.components.length;

    if (this.progress === 1) {
      this.completeSimulator();
    }
  }

  async completeSimulator() {
    this.isComplete = true;
    await this.progressService.updateSimulatorProgress(100);
    
    // Power on sequence
    await this.powerOnSequence();
  }

  async powerOnSequence() {
    this.isPoweredOn = true;
    
    // Start fan animations
    this.fanMeshes.forEach(fan => {
      fan.userData['spinning'] = true;
    });

    // Turn on PSU LED
    this.scene.traverse((obj) => {
      if (obj.userData['isPowerLED'] && obj instanceof THREE.Mesh) {
        (obj.material as THREE.MeshStandardMaterial).emissiveIntensity = 3;
      }
    });

    await this.showToast('⚡ PC Powered On Successfully!', 'success');
  }

  async showToast(message: string, color: string = 'primary') {
    const toast = await this.toastController.create({
      message,
      duration: 2500,
      position: 'top',
      color,
      cssClass: 'custom-toast',
    });
    await toast.present();
  }

  resetSimulator() {
    this.components.forEach((component, index) => {
      component.installed = false;
      component.screwed = false;
      if (component.mesh) {
        const angle = (index / this.components.length) * Math.PI * 1.6 - Math.PI * 0.8;
        const radius = 11;
        component.mesh.position.set(
          Math.sin(angle) * radius,
          1,
          Math.cos(angle) * radius + 4
        );
        component.mesh.rotation.y = -angle;
      }
    });
    this.progress = 0;
    this.isComplete = false;
    this.isPoweredOn = false;
    
    // Stop fans
    this.fanMeshes.forEach(fan => {
      fan.userData['spinning'] = false;
    });
  }

  onWindowResize() {
    const container = this.rendererContainer.nativeElement;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || (window.innerHeight - 200);

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  animate() {
    this.animationId = requestAnimationFrame(() => this.animate());
    
    const delta = this.clock.getDelta();
    const time = this.clock.getElapsedTime();
    
    this.controls.update();

    // Animate RGB lights
    this.rgbLights.forEach((light, i) => {
      const hue = (time * 0.1 + i * 0.33) % 1;
      light.color.setHSL(hue, 1, 0.5);
    });

    // Spin fans
    this.fanMeshes.forEach(fan => {
      if (fan.userData['spinning']) {
        fan.rotation.z += delta * 10; // Fast spin when powered
      }
    });

    // Float uninstalled components
    this.components.forEach(c => {
      if (!c.installed && c.mesh && c !== this.selectedComponent) {
        const baseY = 1;
        c.mesh.position.y = baseY + Math.sin(time * 2 + c.id.length) * 0.12;
        c.mesh.rotation.y += delta * 0.3;
      }
      
      // Pulse ghost meshes
      if (c.ghostMesh && c.ghostMesh.visible && c.ghostMesh.userData['pulsing']) {
        const pulseScale = 1 + Math.sin(time * 3) * 0.05;
        c.ghostMesh.scale.set(pulseScale, pulseScale, pulseScale);
      }
    });

    // Pulse boundary box when dragging
    if (this.boundaryBox && this.isDragging) {
      const mat = this.boundaryBox.material as THREE.LineBasicMaterial;
      mat.opacity = 0.15 + Math.sin(time * 4) * 0.1;
    }

    this.renderer.render(this.scene, this.camera);
  }

  togglePanel() {
    this.panelCollapsed = !this.panelCollapsed;
  }

  getInstalledCount(): number {
    return this.components.filter(c => c.installed).length;
  }

  goHome() {
    this.router.navigate(['/home']);
  }
}

