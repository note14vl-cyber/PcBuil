import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButtons,
  IonBackButton,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonButton,
  IonIcon,
  IonList,
  IonItem,
  IonLabel,
  IonBadge,
  IonProgressBar,
  IonText,
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {
  personCircleOutline,
  trophyOutline,
  videocamOutline,
  helpCircleOutline,
  constructOutline,
  refreshOutline,
  checkmarkCircleOutline,
} from 'ionicons/icons';
import { ProgressService, UserProgress } from '../../services/progress';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
  standalone: true,
  imports: [
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonButtons,
    IonBackButton,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonButton,
    IonIcon,
    IonList,
    IonItem,
    IonLabel,
    IonBadge,
    IonProgressBar,
    IonText,
    CommonModule,
    FormsModule,
  ],
})
export class ProfilePage implements OnInit {
  progress: UserProgress | null = null;
  overallProgress = 0;

  constructor(
    private progressService: ProgressService,
    private router: Router
  ) {
    addIcons({
      personCircleOutline,
      trophyOutline,
      videocamOutline,
      helpCircleOutline,
      constructOutline,
      refreshOutline,
      checkmarkCircleOutline,
    });
  }

  async ngOnInit() {
    await this.loadProgress();
  }

  async ionViewWillEnter() {
    await this.loadProgress();
  }

  async loadProgress() {
    this.progress = await this.progressService.getProgress();
    this.calculateOverallProgress();
  }

  calculateOverallProgress() {
    if (!this.progress) return;

    let completed = 0;
    if (this.progress.level1Completed) completed += 33;
    if (this.progress.level2Completed) completed += 33;
    if (this.progress.level3Completed) completed += 34;

    this.overallProgress = completed / 100;
  }

  async resetProgress() {
    if (confirm('Are you sure you want to reset all progress? This cannot be undone.')) {
      await this.progressService.resetProgress();
      await this.loadProgress();
    }
  }

  getQuizCount(): number {
    if (!this.progress?.quizScores) return 0;
    return Object.keys(this.progress.quizScores).length;
  }

  goHome() {
    this.router.navigate(['/home']);
  }
}
