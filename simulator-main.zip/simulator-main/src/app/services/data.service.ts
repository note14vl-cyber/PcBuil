import { Injectable } from '@angular/core';
import { VideoLesson, Quiz, QuizQuestion } from '../models/interfaces';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  private videoLessons: VideoLesson[] = [
    {
      id: 'lesson-1',
      title: 'Introduction to PC Components',
      description: 'Learn about the essential components that make up a computer system',
      videoUrl: 'https://www.youtube.com/embed/ExxFxD4OSZ0',
      duration: '15:30',
      category: 'Basics',
      keyPoints: [
        'CPU is the brain of the computer',
        'RAM provides temporary storage for active programs',
        'Motherboard connects all components together',
        'Power Supply Unit (PSU) provides electricity to all components',
      ],
    },
    {
      id: 'lesson-2',
      title: 'Safety Procedures and ESD Protection',
      description: 'Essential safety guidelines when working with computer hardware',
      videoUrl: 'https://www.youtube.com/embed/jQRIzgEVsjI',
      duration: '12:45',
      category: 'Safety',
      keyPoints: [
        'Always disconnect power before opening a PC',
        'Use anti-static wrist straps to prevent ESD damage',
        'Work on non-conductive surfaces',
        'Handle components by their edges',
        'Keep liquids away from electronics',
      ],
    },
    {
      id: 'lesson-3',
      title: 'Motherboard Architecture',
      description: 'Understanding motherboard layout, sockets, and connections',
      videoUrl: 'https://www.youtube.com/embed/b2pd3Y6aBag',
      duration: '18:20',
      category: 'Hardware',
      keyPoints: [
        'CPU socket types (LGA, PGA, BGA)',
        'RAM slots and memory channels',
        'PCIe slots for expansion cards',
        'SATA and M.2 connectors for storage',
        'Front panel connectors and headers',
      ],
    },
    {
      id: 'lesson-4',
      title: 'CPU Installation',
      description: 'Step-by-step guide to installing a processor',
      videoUrl: 'https://www.youtube.com/embed/5qczGR4KMnY',
      duration: '10:15',
      category: 'Installation',
      keyPoints: [
        'Align the CPU correctly using the golden triangle',
        'Never force the CPU into the socket',
        'Apply thermal paste properly',
        'Secure the CPU cooler firmly',
      ],
    },
    {
      id: 'lesson-5',
      title: 'RAM Installation and Configuration',
      description: 'Installing memory modules and understanding dual-channel mode',
      videoUrl: 'https://www.youtube.com/embed/cWH2Eqr-Dz0',
      duration: '8:30',
      category: 'Installation',
      keyPoints: [
        'Install RAM in matching pairs for dual-channel',
        'Push firmly until clips lock in place',
        'Check motherboard manual for optimal slot configuration',
        'Verify RAM speed in BIOS',
      ],
    },
    {
      id: 'lesson-6',
      title: 'Graphics Card Installation',
      description: 'Installing and connecting a dedicated GPU',
      videoUrl: 'https://www.youtube.com/embed/nyDxrTHDjXQ',
      duration: '11:00',
      category: 'Installation',
      keyPoints: [
        'Use the top PCIe x16 slot for best performance',
        'Remove necessary slot covers from the case',
        'Connect all required PCIe power cables',
        'Secure the GPU with screws',
      ],
    },
    {
      id: 'lesson-7',
      title: 'Storage Devices: HDD and SSD',
      description: 'Installing hard drives and solid-state drives',
      videoUrl: 'https://www.youtube.com/embed/2jn5R0FKZXY',
      duration: '13:40',
      category: 'Installation',
      keyPoints: [
        'SSDs are faster but more expensive than HDDs',
        'M.2 NVMe drives offer the best performance',
        'Connect SATA cables to both drive and motherboard',
        'Secure drives properly to prevent vibration',
      ],
    },
    {
      id: 'lesson-8',
      title: 'Power Supply Installation',
      description: 'Installing the PSU and cable management',
      videoUrl: 'https://www.youtube.com/embed/i8ZMPkBkHXA',
      duration: '14:25',
      category: 'Installation',
      keyPoints: [
        'Calculate required wattage for your system',
        'Install PSU with fan facing the correct direction',
        'Use modular cables for better cable management',
        'Connect 24-pin ATX and 8-pin CPU power',
      ],
    },
    {
      id: 'lesson-9',
      title: 'Cooling Systems and Fans',
      description: 'Understanding airflow and installing cooling solutions',
      videoUrl: 'https://www.youtube.com/embed/pu7wI4Kn6sc',
      duration: '16:10',
      category: 'Installation',
      keyPoints: [
        'Front fans intake, rear and top fans exhaust',
        'Maintain positive or neutral air pressure',
        'Clean dust filters regularly',
        'Monitor temperatures with software',
      ],
    },
    {
      id: 'lesson-10',
      title: 'Cable Management and Final Assembly',
      description: 'Organizing cables and completing the build',
      videoUrl: 'https://www.youtube.com/embed/c3dggnkaEs8',
      duration: '12:00',
      category: 'Installation',
      keyPoints: [
        'Route cables behind the motherboard tray',
        'Use cable ties to bundle wires together',
        'Connect front panel headers correctly',
        'Double-check all connections before powering on',
      ],
    },
    {
      id: 'lesson-11',
      title: 'Common PC Problems and Troubleshooting',
      description: 'Diagnosing and fixing typical computer issues',
      videoUrl: 'https://www.youtube.com/embed/1W3NNRQNxxg',
      duration: '20:15',
      category: 'Troubleshooting',
      keyPoints: [
        'PC won\'t turn on: Check power connections',
        'No display: Verify GPU is seated properly',
        'Random crashes: Test RAM with memtest86',
        'Overheating: Check thermal paste and fan operation',
        'Use POST codes and beep codes for diagnosis',
      ],
    },
    {
      id: 'lesson-12',
      title: 'BIOS Setup and Configuration',
      description: 'Navigating BIOS/UEFI and optimizing settings',
      videoUrl: 'https://www.youtube.com/embed/LkbH2vZxo0Y',
      duration: '17:30',
      category: 'Configuration',
      keyPoints: [
        'Access BIOS by pressing DEL or F2 during boot',
        'Enable XMP/DOCP for RAM',
        'Set boot priority for OS installation',
        'Update BIOS firmware when necessary',
        'Configure fan curves for optimal cooling',
      ],
    },
  ];

  private quizzes: Quiz[] = [
    {
      id: 'quiz-1',
      title: 'PC Components Fundamentals',
      lessonId: 'lesson-1',
      passingScore: 70,
      questions: [
        {
          id: 'q1-1',
          question: 'What is the primary function of the CPU?',
          options: [
            'Store data permanently',
            'Process instructions and perform calculations',
            'Display graphics on the screen',
            'Provide power to components',
          ],
          correctAnswer: 1,
          explanation: 'The CPU (Central Processing Unit) is the brain of the computer, responsible for executing instructions and performing calculations.',
        },
        {
          id: 'q1-2',
          question: 'Which component provides temporary storage for active programs?',
          options: ['Hard Drive', 'RAM', 'CPU Cache', 'Graphics Card'],
          correctAnswer: 1,
          explanation: 'RAM (Random Access Memory) provides fast, temporary storage for data and programs currently in use.',
        },
        {
          id: 'q1-3',
          question: 'What connects all computer components together?',
          options: ['Power Supply', 'CPU', 'Motherboard', 'Case'],
          correctAnswer: 2,
          explanation: 'The motherboard is the main circuit board that connects and allows communication between all components.',
        },
        {
          id: 'q1-4',
          question: 'What does PSU stand for?',
          options: [
            'Processor Speed Unit',
            'Power Supply Unit',
            'Peripheral Storage Unit',
            'Primary System Utility',
          ],
          correctAnswer: 1,
          explanation: 'PSU stands for Power Supply Unit, which converts AC power to DC power for computer components.',
        },
        {
          id: 'q1-5',
          question: 'Which storage type is fastest?',
          options: ['HDD', 'SATA SSD', 'NVMe SSD', 'External USB Drive'],
          correctAnswer: 2,
          explanation: 'NVMe SSDs use the PCIe interface and offer the fastest storage speeds available for consumer PCs.',
        },
      ],
    },
    {
      id: 'quiz-2',
      title: 'Safety and ESD Protection',
      lessonId: 'lesson-2',
      passingScore: 70,
      questions: [
        {
          id: 'q2-1',
          question: 'What should you do before opening a computer case?',
          options: [
            'Wear rubber gloves',
            'Disconnect all power sources',
            'Turn on the computer',
            'Remove the CPU',
          ],
          correctAnswer: 1,
          explanation: 'Always disconnect power sources to prevent electrical shock and component damage.',
        },
        {
          id: 'q2-2',
          question: 'What does ESD stand for?',
          options: [
            'Electronic System Damage',
            'Electrostatic Discharge',
            'External Storage Device',
            'Emergency Shutdown Device',
          ],
          correctAnswer: 1,
          explanation: 'ESD (Electrostatic Discharge) can damage sensitive electronic components.',
        },
        {
          id: 'q2-3',
          question: 'How should you handle computer components?',
          options: [
            'By any part that\'s convenient',
            'By the edges only',
            'With wet hands for better grip',
            'While wearing wool clothing',
          ],
          correctAnswer: 1,
          explanation: 'Handle components by their edges to avoid touching sensitive circuits and connectors.',
        },
        {
          id: 'q2-4',
          question: 'What is the purpose of an anti-static wrist strap?',
          options: [
            'To look professional',
            'To prevent ESD damage',
            'To improve grip',
            'To measure voltage',
          ],
          correctAnswer: 1,
          explanation: 'Anti-static wrist straps ground you to prevent static electricity from damaging components.',
        },
        {
          id: 'q2-5',
          question: 'What type of surface should you work on?',
          options: [
            'Carpet',
            'Metal table',
            'Non-conductive surface',
            'Wet surface',
          ],
          correctAnswer: 2,
          explanation: 'Non-conductive surfaces prevent accidental short circuits and ESD.',
        },
      ],
    },
    {
      id: 'quiz-3',
      title: 'Installation Procedures',
      lessonId: 'lesson-4',
      passingScore: 70,
      questions: [
        {
          id: 'q3-1',
          question: 'How do you align a CPU correctly in the socket?',
          options: [
            'Force it until it fits',
            'Use the golden triangle marker',
            'It doesn\'t matter',
            'Rotate it until it drops in',
          ],
          correctAnswer: 1,
          explanation: 'The golden triangle on the CPU must align with the triangle on the socket for correct installation.',
        },
        {
          id: 'q3-2',
          question: 'When should you apply thermal paste?',
          options: [
            'Before installing the CPU',
            'After installing the CPU, before the cooler',
            'After installing the cooler',
            'Thermal paste is not necessary',
          ],
          correctAnswer: 1,
          explanation: 'Apply thermal paste on top of the installed CPU before mounting the cooler for optimal heat transfer.',
        },
        {
          id: 'q3-3',
          question: 'For dual-channel memory, where should you install two RAM sticks?',
          options: [
            'In any two slots',
            'In slots 1 and 2',
            'In matching color-coded slots',
            'In slots 3 and 4 only',
          ],
          correctAnswer: 2,
          explanation: 'Install RAM in matching color-coded slots (usually slots 2 and 4) for dual-channel operation.',
        },
        {
          id: 'q3-4',
          question: 'Which PCIe slot should you use for a graphics card?',
          options: [
            'Any available slot',
            'The bottom slot',
            'The top PCIe x16 slot',
            'The shortest slot',
          ],
          correctAnswer: 2,
          explanation: 'Use the top PCIe x16 slot as it typically has the most bandwidth and direct CPU connection.',
        },
        {
          id: 'q3-5',
          question: 'What is the minimum PSU connection to the motherboard?',
          options: [
            'Only 24-pin ATX',
            '24-pin ATX and 8-pin CPU power',
            'Only 8-pin CPU power',
            'No connections needed',
          ],
          correctAnswer: 1,
          explanation: 'Both the 24-pin ATX and 8-pin CPU power connectors are required for the motherboard to function.',
        },
      ],
    },
  ];

  constructor() {}

  getVideoLessons(): VideoLesson[] {
    return this.videoLessons;
  }

  getVideoLessonById(id: string): VideoLesson | undefined {
    return this.videoLessons.find((lesson) => lesson.id === id);
  }

  getQuizzes(): Quiz[] {
    return this.quizzes;
  }

  getQuizById(id: string): Quiz | undefined {
    return this.quizzes.find((quiz) => quiz.id === id);
  }

  getQuizByLessonId(lessonId: string): Quiz | undefined {
    return this.quizzes.find((quiz) => quiz.lessonId === lessonId);
  }
}
