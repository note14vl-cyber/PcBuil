import { Injectable } from '@angular/core';
import { StorageService } from './storage';

export interface UserProgress {
  level1Completed: boolean;
  level2Completed: boolean;
  level3Completed: boolean;
  videosWatched: string[];
  quizScores: { [key: string]: number };
  currentLevel: number;
  simulatorProgress: number;
}

@Injectable({
  providedIn: 'root',
})
export class ProgressService {
  private readonly PROGRESS_KEY = 'user_progress';

  constructor(private storage: StorageService) {}

  async getProgress(): Promise<UserProgress> {
    const progress = await this.storage.get(this.PROGRESS_KEY);
    return progress || this.getDefaultProgress();
  }

  private getDefaultProgress(): UserProgress {
    return {
      level1Completed: false,
      level2Completed: false,
      level3Completed: false,
      videosWatched: [],
      quizScores: {},
      currentLevel: 1,
      simulatorProgress: 0,
    };
  }

  async saveProgress(progress: UserProgress) {
    await this.storage.set(this.PROGRESS_KEY, progress);
  }

  async markVideoWatched(videoId: string) {
    const progress = await this.getProgress();
    if (!progress.videosWatched.includes(videoId)) {
      progress.videosWatched.push(videoId);
      await this.saveProgress(progress);
    }
  }

  async saveQuizScore(quizId: string, score: number) {
    const progress = await this.getProgress();
    progress.quizScores[quizId] = score;
    await this.saveProgress(progress);
  }

  async unlockLevel(level: number) {
    const progress = await this.getProgress();
    progress.currentLevel = Math.max(progress.currentLevel, level);
    
    if (level === 2) progress.level1Completed = true;
    if (level === 3) progress.level2Completed = true;
    
    await this.saveProgress(progress);
  }

  async updateSimulatorProgress(percentage: number) {
    const progress = await this.getProgress();
    progress.simulatorProgress = percentage;
    if (percentage >= 100) {
      progress.level3Completed = true;
    }
    await this.saveProgress(progress);
  }

  async resetProgress() {
    await this.storage.set(this.PROGRESS_KEY, this.getDefaultProgress());
  }
}
